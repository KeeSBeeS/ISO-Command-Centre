@extends('layouts.app')
@section('title','Upload Attendance CSV | ISO Admin')
@section('page_title','Upload Attendance CSV')
@section('content')
<div class="grid cols-2">
    <div class="card">
        <h2>Upload CSV Export</h2>
        <p class="muted">Upload the exported attendance CSV. The importer only uses <strong>Name</strong>, <strong>Time</strong> and <strong>Attendance Status</strong>.</p>
        <form method="post" action="{{ route('attendance.import') }}" enctype="multipart/form-data">
            @csrf
            <div class="form-row"><label>CSV File</label><input type="file" name="csv_file" accept=".csv,text/csv,text/plain" required></div>
            <div class="actions"><button class="btn primary" type="submit">Import CSV</button><a class="btn" href="{{ route('attendance.index') }}">Cancel</a></div>
        </form>
    </div>
    <div class="card">
        <h2>Import Rule</h2>
        <p class="muted">For each employee and date, the earliest timestamp becomes the start time and the latest timestamp becomes the checkout time.</p>
        <p class="muted">If the CSV employee name does not match an active system employee, the row is skipped. Use the employee field <strong>Attendance CSV Name</strong> when the CSV name differs from the employee profile name.</p>
    </div>
</div>
@endsection
