<?php

namespace App\Services;

use App\Models\AttendanceDay;
use App\Models\AttendanceImport;
use App\Models\AttendanceRawRecord;
use App\Models\PublicHoliday;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class AttendanceCsvImporter
{
    public function importString(string $csvContent, array $meta = []): AttendanceImport
    {
        return DB::transaction(function () use ($csvContent, $meta) {
            $import = AttendanceImport::create([
                'source' => $meta['source'] ?? 'upload',
                'source_identifier' => $meta['source_identifier'] ?? null,
                'filename' => $meta['filename'] ?? 'attendance.csv',
                'received_from' => $meta['received_from'] ?? null,
                'received_subject' => $meta['received_subject'] ?? null,
                'received_at' => $meta['received_at'] ?? now(),
                'imported_by' => $meta['imported_by'] ?? null,
                'raw_rows' => 0,
                'matched_rows' => 0,
                'skipped_rows' => 0,
                'day_rows' => 0,
                'status' => 'processing',
                'notes' => null,
            ]);

            [$headers, $rows] = $this->readCsv($csvContent);
            $nameIndex = $this->findHeader($headers, ['name']);
            $timeIndex = $this->findHeader($headers, ['time']);
            $statusIndex = $this->findHeader($headers, ['attendance status', 'status']);

            if ($nameIndex === null || $timeIndex === null) {
                $import->update([
                    'status' => 'failed',
                    'notes' => 'CSV must contain Name and Time columns.',
                ]);

                return $import;
            }

            $rawRows = 0;
            $matchedRows = 0;
            $skippedRows = 0;
            $affected = [];

            foreach ($rows as $row) {
                if (!$this->rowHasValues($row)) {
                    continue;
                }

                $rawRows++;
                $name = trim((string) ($row[$nameIndex] ?? ''));
                $timeValue = trim((string) ($row[$timeIndex] ?? ''));
                $status = $statusIndex !== null ? trim((string) ($row[$statusIndex] ?? '')) : null;

                if ($name === '' || $timeValue === '') {
                    $skippedRows++;
                    continue;
                }

                $employee = $this->findEmployee($name);
                if (!$employee) {
                    $skippedRows++;
                    continue;
                }

                $recordedAt = $this->parseDateTime($timeValue);
                if (!$recordedAt) {
                    $skippedRows++;
                    continue;
                }

                $hash = $this->rowHash($employee->id, $name, $timeValue, $status);
                $record = AttendanceRawRecord::firstOrCreate(
                    ['source_row_hash' => $hash],
                    [
                        'attendance_import_id' => $import->id,
                        'user_id' => $employee->id,
                        'employee_name' => $name,
                        'attendance_status' => $status ?: null,
                        'recorded_at' => $recordedAt,
                        'attendance_date' => $recordedAt->toDateString(),
                    ]
                );

                if ($record->wasRecentlyCreated) {
                    $matchedRows++;
                }

                $affected[$employee->id . '|' . $recordedAt->toDateString()] = [
                    'user_id' => $employee->id,
                    'date' => $recordedAt->toDateString(),
                ];
            }

            $dayRows = 0;
            foreach ($affected as $item) {
                $this->rebuildDay($item['user_id'], $item['date'], $import->id);
                $dayRows++;
            }

            $import->update([
                'raw_rows' => $rawRows,
                'matched_rows' => $matchedRows,
                'skipped_rows' => $skippedRows,
                'day_rows' => $dayRows,
                'status' => 'completed',
                'notes' => $skippedRows > 0 ? $skippedRows . ' row(s) skipped because the employee did not exist or the row was invalid.' : null,
            ]);

            return $import;
        });
    }

    private function readCsv(string $content): array
    {
        $content = preg_replace('/^\xEF\xBB\xBF/', '', $content ?? '');
        $handle = fopen('php://temp', 'r+');
        fwrite($handle, $content);
        rewind($handle);

        $headers = fgetcsv($handle);
        if (!$headers) {
            fclose($handle);
            return [[], []];
        }

        $rows = [];
        while (($row = fgetcsv($handle)) !== false) {
            $rows[] = $row;
        }
        fclose($handle);

        return [$headers, $rows];
    }

    private function findHeader(array $headers, array $names): ?int
    {
        $normalised = array_map(fn ($value) => Str::lower(trim((string) $value)), $headers);
        foreach ($names as $name) {
            $index = array_search(Str::lower($name), $normalised, true);
            if ($index !== false) {
                return $index;
            }
        }

        return null;
    }

    private function rowHasValues(array $row): bool
    {
        foreach ($row as $value) {
            if (trim((string) $value) !== '') {
                return true;
            }
        }

        return false;
    }

    private function findEmployee(string $attendanceName): ?User
    {
        $name = trim($attendanceName);
        $query = User::query()->where('status', 'active');

        if (Schema::hasColumn('users', 'attendance_name')) {
            $employee = (clone $query)->where('attendance_name', $name)->first();
            if ($employee) {
                return $employee;
            }
        }

        $employee = (clone $query)->where('name', $name)->first();
        if ($employee) {
            return $employee;
        }

        $normalised = Str::lower($name);
        if (Schema::hasColumn('users', 'attendance_name')) {
            $employee = (clone $query)->whereRaw('LOWER(attendance_name) = ?', [$normalised])->first();
            if ($employee) {
                return $employee;
            }
        }

        return (clone $query)->whereRaw('LOWER(name) = ?', [$normalised])->first();
    }

    private function parseDateTime(string $value): ?Carbon
    {
        $value = trim($value);
        $formats = [
            'Y-m-d H:i:s',
            'Y/m/d H:i:s',
            'd/m/Y H:i:s',
            'd-m-Y H:i:s',
            'Y-m-d H:i',
            'd/m/Y H:i',
        ];

        foreach ($formats as $format) {
            try {
                return Carbon::createFromFormat($format, $value);
            } catch (\Throwable $e) {
                // Try next format.
            }
        }

        try {
            return Carbon::parse($value);
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function rowHash(int $userId, string $name, string $time, ?string $status): string
    {
        return hash('sha256', implode('|', [$userId, Str::lower(trim($name)), trim($time), Str::lower(trim((string) $status))]));
    }

    public function rebuildAllExistingDays(): int
    {
        if (!Schema::hasTable('attendance_raw_records')) {
            return 0;
        }

        $items = AttendanceRawRecord::query()
            ->select('user_id', 'attendance_date')
            ->whereNotNull('user_id')
            ->distinct()
            ->get();

        $rebuilt = 0;
        foreach ($items as $item) {
            $existingDay = AttendanceDay::query()
                ->where('user_id', $item->user_id)
                ->whereDate('attendance_date', $item->attendance_date)
                ->first();

            $this->rebuildDay((int) $item->user_id, $item->attendance_date->toDateString(), $existingDay?->attendance_import_id);
            $rebuilt++;
        }

        return $rebuilt;
    }

    public function rebuildDay(int $userId, string $date, ?int $importId = null): void
    {
        $records = AttendanceRawRecord::query()
            ->where('user_id', $userId)
            ->whereDate('attendance_date', $date)
            ->orderBy('recorded_at')
            ->get();

        if ($records->isEmpty()) {
            return;
        }

        $cutoff = Carbon::parse($date . ' 09:00:00');
        $publicHoliday = $this->publicHolidayFor($date);
        $isPublicHoliday = (bool) $publicHoliday;

        $recordsBeforeCutoff = $records->filter(function (AttendanceRawRecord $record) use ($cutoff) {
            return $record->recorded_at && $record->recorded_at->lte($cutoff);
        })->values();

        // Clock-in is only accepted until 09:00. If there are multiple records before 09:00,
        // only the earliest one becomes the clock-in. If none exist before 09:00, the earliest
        // available record becomes the late clock-in and the day is flagged.
        $first = $recordsBeforeCutoff->isNotEmpty() ? $recordsBeforeCutoff->first() : $records->first();
        $last = $records->last();

        $endTime = null;
        $minutes = 0;
        if ($first->recorded_at && $last->recorded_at && !$first->recorded_at->equalTo($last->recorded_at)) {
            $endTime = $last->recorded_at;
            $minutes = max(0, $first->recorded_at->diffInMinutes($last->recorded_at, false));
        }

        $isLate = false;
        $lateMinutes = 0;
        if (!$isPublicHoliday && $first->recorded_at && $first->recorded_at->gt($cutoff)) {
            $isLate = true;
            $lateMinutes = max(1, $cutoff->diffInMinutes($first->recorded_at, false));
        }

        if ($isPublicHoliday) {
            // The company is closed on public holidays. Keep the raw record for audit, but do
            // not count it as a normal working day or late clock-in.
            $minutes = 0;
            $isLate = false;
            $lateMinutes = 0;
        }

        $anomalies = [];
        if ($isPublicHoliday) {
            $anomalies[] = 'Public holiday / company closed: ' . $publicHoliday->name . '. Attendance is retained for audit only.';
        }
        if ($recordsBeforeCutoff->count() > 1) {
            $anomalies[] = 'Multiple clock-ins before 09:00; earliest time kept as check-in.';
        }
        if ($records->count() === 1) {
            $anomalies[] = 'Only one attendance record found for this day; checkout could not be calculated.';
        }
        if ($first->recorded_at && $last->recorded_at && $first->recorded_at->equalTo($last->recorded_at)) {
            $anomalies[] = 'Clock-in and checkout time were the same; checkout was left blank.';
        }
        if ($isLate) {
            $anomalies[] = 'Late clock-in after 09:00.';
        }

        $payload = [
            'start_time' => $first->recorded_at,
            'end_time' => $endTime,
            'first_status' => $first->attendance_status,
            'last_status' => $endTime ? $last->attendance_status : null,
            'record_count' => $records->count(),
            'work_minutes' => $minutes,
            'attendance_import_id' => $importId,
            'source_names' => $records->pluck('employee_name')->unique()->implode(', '),
            'anomalies' => implode(' ', $anomalies) ?: null,
        ];

        if (Schema::hasColumn('attendance_days', 'is_late')) {
            $payload['is_late'] = $isLate;
            $payload['late_minutes'] = $lateMinutes;
        }
        if (Schema::hasColumn('attendance_days', 'is_public_holiday')) {
            $payload['is_public_holiday'] = $isPublicHoliday;
            $payload['public_holiday_name'] = $publicHoliday?->name;
        }

        AttendanceDay::updateOrCreate(
            ['user_id' => $userId, 'attendance_date' => $date],
            $payload
        );
    }

    private function publicHolidayFor(string $date): ?PublicHoliday
    {
        if (!Schema::hasTable('public_holidays')) {
            return null;
        }

        return PublicHoliday::query()
            ->whereDate('holiday_date', $date)
            ->where('is_company_closed', true)
            ->first();
    }
}
