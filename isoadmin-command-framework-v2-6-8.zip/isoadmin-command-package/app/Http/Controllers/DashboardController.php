<?php

namespace App\Http\Controllers;

use App\Models\AttendanceDay;
use App\Models\AttendanceImport;
use App\Models\DashboardWidgetPreference;
use App\Models\Department;
use App\Models\EmployeeDocument;
use App\Models\LeaveRequest;
use App\Models\Role;
use App\Models\User;
use App\Models\Vehicle;
use App\Models\VehicleDocument;
use App\Models\VehicleFuelUp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $metrics = $this->metrics($user);
        $availableWidgets = $this->availableWidgets($user, $metrics);
        $dashboardWidgets = $this->resolvedWidgets($user, $availableWidgets);

        return view('dashboard', array_merge($metrics, [
            'dashboardWidgets' => $dashboardWidgets,
            'dashboardPreferencesReady' => Schema::hasTable('dashboard_widget_preferences'),
        ]));
    }

    public function edit(Request $request)
    {
        abort_unless(Schema::hasTable('dashboard_widget_preferences'), 404, 'Run the v1.5 update first.');

        $user = $request->user();
        $metrics = $this->metrics($user);
        $availableWidgets = $this->availableWidgets($user, $metrics);
        $dashboardWidgets = $this->resolvedWidgets($user, $availableWidgets, true);

        return view('dashboard_edit', [
            'dashboardWidgets' => $dashboardWidgets,
            'sizes' => $this->sizes(),
        ]);
    }

    public function update(Request $request)
    {
        abort_unless(Schema::hasTable('dashboard_widget_preferences'), 404, 'Run the v1.5 update first.');

        $user = $request->user();
        $available = collect($this->availableWidgets($user, $this->metrics($user)))->keyBy('key');

        $data = $request->validate([
            'widgets' => ['nullable', 'array'],
            'widgets.*.sort_order' => ['nullable', 'integer', 'min:0', 'max:500'],
            'widgets.*.size' => ['nullable', 'in:small,medium,large'],
            'widgets.*.visible' => ['nullable', 'boolean'],
        ]);

        foreach ($available as $key => $widget) {
            $input = $data['widgets'][$key] ?? [];

            DashboardWidgetPreference::updateOrCreate(
                ['user_id' => $user->id, 'widget_key' => $key],
                [
                    'sort_order' => (int) ($input['sort_order'] ?? $widget['default_order']),
                    'size' => $input['size'] ?? $widget['default_size'],
                    'is_visible' => array_key_exists('visible', $input),
                ]
            );
        }

        return redirect()->route('dashboard')->with('success', 'Dashboard layout saved.');
    }

    private function metrics(?User $viewer = null): array
    {
        $attendanceReady = Schema::hasTable('attendance_days');
        $documentsReady = Schema::hasTable('employee_documents');
        $vehiclesReady = Schema::hasTable('vehicles');
        $fuelReady = Schema::hasTable('vehicle_fuel_ups');
        $vehicleDocumentsReady = Schema::hasTable('vehicle_documents');
        $vehicleServiceReady = Schema::hasTable('vehicle_service_records') && Schema::hasColumn('vehicles', 'service_interval_km');
        $leaveReady = Schema::hasTable('leave_requests') && Schema::hasTable('leave_types');
        $vehicleServiceReminderCount = 0;
        if ($vehicleServiceReady) {
            $vehicleServiceReminderCount = Vehicle::where('status', 'active')->get()->filter(function (Vehicle $vehicle) {
                return in_array($vehicle->service_summary['state'], ['overdue', 'due-soon'], true);
            })->count();
        }

        return [
            'employeeCount' => User::count(),
            'activeEmployeeCount' => User::where('status', 'active')->count(),
            'departmentCount' => Department::count(),
            'roleCount' => Role::count(),
            'attendanceReady' => $attendanceReady,
            'todayAttendanceCount' => $attendanceReady ? AttendanceDay::whereDate('attendance_date', now()->toDateString())->count() : 0,
            'todaySingleRecordCount' => $attendanceReady ? AttendanceDay::whereDate('attendance_date', now()->toDateString())->where('record_count', '<=', 1)->count() : 0,
            'latestAttendanceImport' => Schema::hasTable('attendance_imports') ? AttendanceImport::latest()->first() : null,
            'documentsReady' => $documentsReady,
            'activeDocumentCount' => $documentsReady ? EmployeeDocument::where('status', 'active')->count() : 0,
            'expiringDocumentCount' => $documentsReady ? EmployeeDocument::reminderDue()->count() : 0,
            'expiredDocumentCount' => $documentsReady ? EmployeeDocument::where('status', 'active')->where('has_expiry', true)->whereDate('expires_at', '<', now()->toDateString())->count() : 0,
            'vehiclesReady' => $vehiclesReady,
            'vehicleCount' => $vehiclesReady ? Vehicle::count() : 0,
            'activeVehicleCount' => $vehiclesReady ? Vehicle::where('status', 'active')->count() : 0,
            'fuelReady' => $fuelReady,
            'fuelUpsThisMonth' => $fuelReady ? VehicleFuelUp::whereDate('fuelup_date', '>=', now()->startOfMonth()->toDateString())->count() : 0,
            'fuelLitresThisMonth' => $fuelReady ? VehicleFuelUp::whereDate('fuelup_date', '>=', now()->startOfMonth()->toDateString())->sum('litres') : 0,
            'fuelCostThisMonth' => $fuelReady ? VehicleFuelUp::whereDate('fuelup_date', '>=', now()->startOfMonth()->toDateString())->sum('total_cost') : 0,
            'vehicleDocumentsReady' => $vehicleDocumentsReady,
            'vehicleDocumentReminderCount' => $vehicleDocumentsReady ? VehicleDocument::reminderDue()->count() : 0,
            'vehicleServiceReady' => $vehicleServiceReady,
            'vehicleServiceReminderCount' => $vehicleServiceReminderCount,
            'leaveReady' => $leaveReady,
            'pendingLeaveCount' => $leaveReady ? LeaveRequest::query()->when($viewer, fn($query) => $query->visibleTo($viewer))->where('status', 'pending')->count() : 0,
            'approvedLeaveThisMonth' => $leaveReady ? LeaveRequest::query()->when($viewer, fn($query) => $query->visibleTo($viewer))->where('status', 'approved')->whereDate('start_date', '>=', now()->startOfMonth()->toDateString())->whereDate('start_date', '<=', now()->endOfMonth()->toDateString())->count() : 0,
        ];
    }

    private function availableWidgets(User $user, array $metrics): array
    {
        $widgets = [
            [
                'key' => 'company_summary',
                'title' => 'Company Summary',
                'description' => 'Employees, departments and roles.',
                'default_size' => 'large',
                'default_order' => 10,
                'available' => true,
            ],
            [
                'key' => 'quick_actions',
                'title' => 'Quick Actions',
                'description' => 'Fast access to the most-used command areas.',
                'default_size' => 'medium',
                'default_order' => 20,
                'available' => true,
            ],
            [
                'key' => 'leave_calendar',
                'title' => 'Leave & Calendar',
                'description' => 'Leave requests and calendar visibility.',
                'default_size' => 'medium',
                'default_order' => 25,
                'available' => $metrics['leaveReady'] && $user->hasAnyPermission(['leave.view', 'calendar.view']),
            ],
            [
                'key' => 'attendance_today',
                'title' => 'Attendance Today',
                'description' => 'Daily attendance count and single-punch flags.',
                'default_size' => 'medium',
                'default_order' => 30,
                'available' => $metrics['attendanceReady'] && $user->hasPermission('attendance.view'),
            ],
            [
                'key' => 'employee_documents',
                'title' => 'Employee Documents',
                'description' => 'Active, expiring and expired employee documents.',
                'default_size' => 'medium',
                'default_order' => 40,
                'available' => $metrics['documentsReady'] && $user->hasPermission('employee_documents.view'),
            ],
            [
                'key' => 'vehicles',
                'title' => 'Vehicles',
                'description' => 'Fleet count and active vehicle summary.',
                'default_size' => 'medium',
                'default_order' => 50,
                'available' => $metrics['vehiclesReady'] && $user->hasPermission('vehicle.view'),
            ],
            [
                'key' => 'fuel_this_month',
                'title' => 'Fuel This Month',
                'description' => 'Fuel-up count, litres and cost this month.',
                'default_size' => 'medium',
                'default_order' => 60,
                'available' => $metrics['fuelReady'] && $user->hasPermission('vehicle.fuel.view'),
            ],
            [
                'key' => 'vehicle_reminders',
                'title' => 'Vehicle Reminders',
                'description' => 'NATIS, license disk and vehicle document reminders.',
                'default_size' => 'small',
                'default_order' => 70,
                'available' => $metrics['vehicleDocumentsReady'] && $user->hasPermission('vehicle.reminders.view'),
            ],
            [
                'key' => 'vehicle_service_reminders',
                'title' => 'Vehicle Service Reminders',
                'description' => 'Upcoming and overdue vehicle services based on latest ODO.',
                'default_size' => 'small',
                'default_order' => 75,
                'available' => $metrics['vehicleServiceReady'] && $user->hasPermission('vehicle.service.reminders.view'),
            ],
            [
                'key' => 'access_model',
                'title' => 'Access Model',
                'description' => 'Director, manager, employee and custom-role structure.',
                'default_size' => 'small',
                'default_order' => 80,
                'available' => true,
            ],
        ];

        return array_values(array_filter($widgets, fn ($widget) => $widget['available']));
    }

    private function resolvedWidgets(User $user, array $availableWidgets, bool $includeHidden = false): array
    {
        $preferences = collect();
        if (Schema::hasTable('dashboard_widget_preferences')) {
            $preferences = DashboardWidgetPreference::where('user_id', $user->id)->get()->keyBy('widget_key');
        }

        $widgets = [];
        foreach ($availableWidgets as $widget) {
            $preference = $preferences->get($widget['key']);
            $widget['size'] = $preference?->size ?: $widget['default_size'];
            $widget['sort_order'] = $preference?->sort_order ?? $widget['default_order'];
            $widget['is_visible'] = $preference ? (bool) $preference->is_visible : true;

            if ($includeHidden || $widget['is_visible']) {
                $widgets[] = $widget;
            }
        }

        usort($widgets, fn ($a, $b) => [$a['sort_order'], $a['title']] <=> [$b['sort_order'], $b['title']]);

        return $widgets;
    }

    private function sizes(): array
    {
        return [
            'small' => 'Small - compact metric only',
            'medium' => 'Medium - useful summary',
            'large' => 'Large - detailed dashboard block',
        ];
    }
}
